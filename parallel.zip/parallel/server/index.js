const WebSocket = require("ws");
const { SerialPort } = require("serialport");
const { ReadlineParser } = require("@serialport/parser-readline");
const port = new SerialPort({ path: "COM5", baudRate: 9600 });
const fs = require("fs");
const path = require("path");

const registrationWss = new WebSocket.Server({ port: 5000 });
const loginWss = new WebSocket.Server({ port: 5001 });
const rfidSocket = new WebSocket.Server({ port: 5002 });
const attendanceSocket = new WebSocket.Server({ port: 5003 });
const parser = port.pipe(new ReadlineParser({ delimiter: "\r\n" }));

const directoryPath = path.join(__dirname, "images");

// Function to send data to connected WebSocket clients
function sendDataToClients(wss, data) {
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(data);
    }
  });
}

parser.on("data", (data) => {
  const receivedData = data.toString();
  console.log("Received data:", receivedData);

  if (receivedData !== "empty") {
    // Send data to the respective WebSocket server based on its purpose
    sendDataToClients(registrationWss, receivedData); // Send to registration WebSocket clients
    sendDataToClients(loginWss, receivedData); // Send to login WebSocket clients
    sendDataToClients(attendanceSocket, receivedData);
  }
});

rfidSocket.on("connection", (socket) => {
  fs.readdir(directoryPath, (err, files) => {
    if (err) {
      socket.send(JSON.stringify({ error: err.message }));
    } else {
      // Extracting only the file names without extensions
      const fileNames = files.map((file) => path.parse(file).name);
      socket.send(JSON.stringify(fileNames));
    }
  });
});

// Registration WebSocket server
registrationWss.on("connection", function connection(ws) {
  console.log("WebSocket connection established for registration");

  ws.on("close", function () {
    // Handle WebSocket close event for registration if needed
  });

  ws.on("message", function incoming(message) {
    // Handle incoming messages for registration if needed
    console.log("Received message for registration:", message);
    // Process the message for registration if required
  });
});

// Login WebSocket server
loginWss.on("connection", function connection(ws) {
  console.log("WebSocket connection established for login");

  ws.on("close", function () {
    // Handle WebSocket close event for login if needed
  });

  ws.on("message", function incoming(message) {
    // Handle incoming messages for login if needed
    console.log("Received message for login:", message);
    // Process the message for login if required
  });
});

// Login WebSocket server
loginWss.on("connection", function connection(ws) {
  console.log("WebSocket connection established for login");

  ws.on("close", function () {
    // Handle WebSocket close event for login if needed
  });

  ws.on("message", function incoming(message) {
    // Handle incoming messages for login if needed
    console.log("Received message for login:", message);
    // Process the message for login if required
  });
});
// Login WebSocket server
attendanceSocket.on("connection", function connection(ws) {
  console.log("WebSocket connection for attendance is established");

  ws.on("close", function () {
    // Handle WebSocket close event for login if needed
  });

  ws.on("message", function incoming(message) {
    // Handle incoming messages for login if needed
    console.log("Received message for login:", message);
    // Process the message for login if required
  });
});
