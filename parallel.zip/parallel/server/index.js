const WebSocket = require("ws");
const wss = new WebSocket.Server({ port: 5000 }); // Choose your desired port
const { SerialPort } = require("serialport");
const { ReadlineParser } = require("@serialport/parser-readline");
const port = new SerialPort({ path: "COM7", baudRate: 9600 });

let receivedData = "";
let previousData = ""; // Variable to store the previous data received

const parser = port.pipe(new ReadlineParser({ delimiter: "\r\n" }));
parser.on("data", (data) => {
  // Store incoming data in the variable
  receivedData = data.toString(); // Assuming data is a Buffer, convert it to a string
  console.log("Received data:", receivedData); // Optional: Log the received data

  // Check if the received data is different from the previous data
  if (receivedData !== previousData) {
    previousData = receivedData; // Update the previous data with the new value
    // Send the updated data over WebSocket to connected clients
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(receivedData);
      }
    });
  }
});

wss.on("connection", function connection(ws) {
  console.log("WebSocket connection established with PHP client");

  ws.on("close", function () {
    // Handle WebSocket close event if needed
  });

  ws.on("message", function incoming(message) {
    // Handle incoming messages from PHP if needed
    console.log("Received message from PHP:", message);
    // Process the message if required
  });
});
