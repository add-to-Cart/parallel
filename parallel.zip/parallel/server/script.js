const videoElement = document.getElementById("videoElement");
const displayStatus = document.getElementById("displayStatus");
let matchRfid;
let students = []; // Initialize an empty array
let currentInstructor =
  JSON.parse(localStorage.getItem("currentInstructor")) || null; // Retrieve or initialize current instructor
const attendanceSocket = new WebSocket("ws://localhost:5003"); // Connect to your Node.js server

attendanceSocket.onopen = function () {
  console.log("Attendance socket connection established");
};

attendanceSocket.onmessage = function (event) {
  // Handle messages received from Node.js in PHP
  console.log("Received rfid from server:", event.data);
  // Update your PHP application based on the received data

  matchRfid = event.data;
};

//store the array that contains student in a local storage
const storedStudents = localStorage.getItem("studentsArray");
if (storedStudents) {
  students = JSON.parse(storedStudents);
}

// Client-side code
const socket = new WebSocket("ws://localhost:5002"); // Replace 'localhost' with your server IP or domain
let rfidFromSocket;
socket.addEventListener("open", () => {
  console.log("Rfid fetching is enabled");
});

socket.addEventListener("message", (event) => {
  const data = JSON.parse(event.data);
  if (data.error) {
    console.error("Error:", data.error);
  } else {
    rfidFromSocket = data;
    console.log("Available rfids:", rfidFromSocket);

    // Process the received file names here
    // For example, you can display them in the console or update the UI
    // Replace this with your desired logic to handle the received file names
  }
});

socket.addEventListener("close", () => {
  console.log("Connection to the WebSocket server closed");
});

Promise.all([
  faceapi.nets.ssdMobilenetv1.loadFromUri("../server/models"),
  faceapi.nets.faceRecognitionNet.loadFromUri("../server/models"),
  faceapi.nets.faceLandmark68Net.loadFromUri("../server/models"),
]).then(startWebcam);

function startWebcam() {
  navigator.mediaDevices
    .getUserMedia({
      video: true,
      audio: false,
    })
    .then((stream) => {
      videoElement.srcObject = stream;
    })
    .catch((error) => {
      console.error(error);
    });
}

async function fetchImage() {
  const retrieveRfid = [...rfidFromSocket];
  const labeledFaceDescriptors = await Promise.all(
    retrieveRfid.map(async (rfid) => {
      const descriptions = [];
      for (let i = 1; i <= 4; i++) {
        try {
          const img = await faceapi.fetchImage(
            `../server/images/${rfid}/${i}.png`
          );

          const detections = await faceapi
            .detectSingleFace(img)
            .withFaceLandmarks()
            .withFaceDescriptor();

          if (detections) {
            descriptions.push(detections.descriptor);
          } else {
            console.log(`No face detected for ${rfid}/${i}.png`);
          }
        } catch (error) {
          console.error("Error processing image:", error);
        }
      }

      try {
        const rfidInfo = await handleRFIDScan(rfid);
        if (rfidInfo) {
          return new faceapi.LabeledFaceDescriptors(rfidInfo, descriptions);
        } else {
          console.log(`No valid info found for RFID: ${rfid}`);
          return null; // or handle the absence of valid info
        }
      } catch (error) {
        console.error("Error fetching RFID info:", error);
        return null; // or handle error cases accordingly
      }
    })
  );

  return labeledFaceDescriptors.filter((descriptor) => descriptor !== null);
}
async function handleRFIDScan(rfid) {
  try {
    const response = await fetch(`../php/fetch_rfid_info.php?rfid=${rfid}`);
    const data = await response.json();

    if (Array.isArray(data) && data.length > 0) {
      const { rfid: retrieveRfid, lastname, firstname, middlename } = data[0];
      const fullDetails = `${retrieveRfid} ${firstname} ${middlename} ${lastname}`;
      return fullDetails;
    } else {
      console.log("No records found");
      return null; // or handle no records found scenario
    }
  } catch (error) {
    console.error("Error fetching data:", error);
    throw error;
  }
}
videoElement.addEventListener("play", async () => {
  const labeledFaceDescriptors = await fetchImage();
  const faceMatcher = new faceapi.FaceMatcher(labeledFaceDescriptors);

  const canvas = faceapi.createCanvasFromMedia(videoElement);
  document.getElementById("videoContainer").append(canvas);

  const displaySize = {
    width: videoElement.width,
    height: videoElement.height,
  };

  faceapi.matchDimensions(canvas, displaySize);

  setInterval(async () => {
    const detections = await faceapi
      .detectAllFaces(videoElement)
      .withFaceLandmarks()
      .withFaceDescriptors();

    const resizedDetections = faceapi.resizeResults(detections, displaySize);

    canvas.getContext("2d").clearRect(0, 0, canvas.width, canvas.height);

    const results = resizedDetections.map((d) => {
      return faceMatcher.findBestMatch(d.descriptor);
    });

    results.forEach((result, i) => {
      const box = resizedDetections[i].detection.box;
      const resultFullname = result.toString();
      const partFullname = resultFullname.split(" ");
      partFullname.shift();
      const processedFullname = partFullname.join(" ");
      const drawBox = new faceapi.draw.DrawBox(box, {
        label: processedFullname,
      });

      const rfidResult = result.toString();

      drawBox.draw(canvas);

      if (result.label !== "unknown") {
        const processFaceRfid = rfidResult.split(" ")[0];
        console.log(processFaceRfid);
        if (!matchRfid) {
          displayStatus.innerText = "Please scan your RFID!";
          displayStatus.classList.add("alert-warning");
          displayStatus.classList.remove("d-none");
        } else if (matchRfid !== null && matchRfid === processFaceRfid) {
          fetchRoleFromDatabase(processFaceRfid)
            .then((response) => {
              if (response.success) {
                const roleInfo = response.roleInfo;
                if (roleInfo.role === "student") {
                  // If the scanned ID belongs to a student
                  handleStudent(roleInfo);
                  console.log(roleInfo);
                } else if (roleInfo.role === "instructor") {
                  // If the scanned ID belongs to an instructor
                  if (currentInstructor != null) {
                    if (currentInstructor.rfid == roleInfo.rfid) {
                      currentInstructor = null;
                      localStorage.removeItem("currentInstructor");
                      console.log(currentInstructor);
                    } else {
                      handleInstructor(roleInfo);
                    }
                  } else {
                    handleInstructor(roleInfo);
                  }
                } else {
                  console.log(roleInfo);
                  displayStatus.innerText = "Invalid role for the scanned ID.";
                }
              } else {
                displayStatus.innerText = response.message;
              }
            })
            .catch((error) => {
              console.error("Error fetching role from database:", error);
              displayStatus.innerText = "Error fetching role from database.";
            });

          matchRfid = null;
          displayStatus.classList.remove("alert-warning", "alert-danger");
          displayStatus.classList.add("alert-success");
          displayStatus.innerText = "You are now Present!";

          console.log("matchRfid is now null.");

          setTimeout(() => {}, 5000);
        } else if (matchRfid !== null && matchRfid !== processFaceRfid) {
          displayStatus.classList.remove("alert-warning", "alert-success");
          displayStatus.classList.add("alert-danger");
          displayStatus.innerText = "RFID and face do not match!";
          setTimeout(() => {}, 5000);
        }
      }
    });
  }, 100);
});

function handleStudent(studentInfo) {
  const existingIndex = students.findIndex(
    (student) => student.rfid === studentInfo.rfid
  );

  if (existingIndex !== -1) {
    students.splice(existingIndex, 1);
    displayStatus.innerText =
      "Student removed from attendance: " + studentInfo.rfid;
  } else {
    if (currentInstructor != null) {
      student = {
        rfid: studentInfo.rfid,
        firstname: studentInfo.firstname,
        middlename: studentInfo.middlename,
        lastname: studentInfo.lastname,
      };

      insertSingleStudentIntoDatabase(student, currentInstructor)
        .then((response) => {
          console.log("Students inserted with instructor:", response);
        })
        .catch((error) => {
          console.error("Error inserting students:", error);
        });
    }
    students.push(studentInfo);
    displayStatus.innerText =
      "Student added to attendance: " + studentInfo.rfid;
  }

  localStorage.setItem("studentsArray", JSON.stringify(students));
}

// function handleSingleStudent(studentInfo) {
//   student = {
//     rfid: studentInfo.rfid,
//     firstname: studentInfo.firstname,
//     middlename: studentInfo.middlename,
//     lastname: studentInfo.lastname,
//   };

//   insertSingleStudentIntoDatabase(student, currentInstructor)
//     .then((response) => {
//       console.log("Students inserted with instructor:", response);
//     })
//     .catch((error) => {
//       console.error("Error inserting students:", error);
//     });
// }

function handleInstructor(instructorInfo) {
  currentInstructor = {
    rfid: instructorInfo.rfid,
    firstname: instructorInfo.firstname,
    middlename: instructorInfo.middlename,
    lastname: instructorInfo.lastname,
    role: instructorInfo.role,
  };
  localStorage.setItem("currentInstructor", JSON.stringify(currentInstructor));

  displayStatus.innerText =
    "Instructor detected: " +
    instructorInfo.lastname +
    ", " +
    instructorInfo.firstname;
  insertInstructor(currentInstructor);

  if (students.length > 0) {
    insertStudentsIntoDatabase(currentInstructor, students)
      .then((response) => {
        console.log("Students inserted with instructor:", response);
      })
      .catch((error) => {
        console.error("Error inserting students:", error);
      });
  }
}

function fetchRoleFromDatabase(rfid) {
  return fetch("../php/fetch_role.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ rfid: rfid }),
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok.");
      }
      return response.json();
    })
    .catch((error) => {
      console.error("Error:", error);
      return { success: false, message: "Error fetching role from database." };
    });
}

function insertSingleStudentIntoDatabase(student, instructorInfo) {
  return fetch("../php/push_student.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      instructorInfo: instructorInfo,
      student: student,
    }),
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok.");
      }
      return response.json();
    })
    .catch((error) => {
      console.error("Error inserting attendance:", error);
      return { success: false, message: "Error inserting attendance." };
    });
}

function insertStudentsIntoDatabase(instructorInfo, studentsArray) {
  return fetch("../php/push_attendance.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      instructorInfo: instructorInfo,
      studentsArray: studentsArray,
    }),
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok.");
      }
      return response.json();
    })
    .catch((error) => {
      console.error("Error inserting attendance:", error);
      return { success: false, message: "Error inserting attendance." };
    });
}

function insertInstructor(instructorInfo) {
  return fetch("../php/push_instructor.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      instructorInfo: instructorInfo,
    }),
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok.");
      }
      return response.json();
    })
    .catch((error) => {
      console.error("Error inserting attendance:", error);
      return { success: false, message: "Error inserting attendance." };
    });
}
