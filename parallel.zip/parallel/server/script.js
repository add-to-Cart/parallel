const videoElement = document.getElementById("videoElement");
const displayStatus = document.getElementById("displayStatus");
const displayRfid = document.getElementById("displayRfid");
let matchfaceRfid;
let matchRfid;
const attendanceSocket = new WebSocket("ws://localhost:5003"); // Connect to your Node.js server

attendanceSocket.onopen = function () {
  console.log("Attendance socket connection established");
};

attendanceSocket.onmessage = function (event) {
  // Handle messages received from Node.js in PHP
  console.log("Received rfid from server:", event.data);
  // Update your PHP application based on the received data

  displayRfid.innerText = event.data;
  matchRfid = event.data;
};

// Client-side code
const socket = new WebSocket("ws://localhost:5002"); // Replace 'localhost' with your server IP or domain
let rfidFromSocket;
socket.addEventListener("open", () => {
  console.log("Rfid fetching is enabled");
});

socket.addEventListener("message", (event) => {
  const data = JSON.parse(event.data);
  if (data.error) {
    console.error("Error:", data.error);
  } else {
    rfidFromSocket = data;
    console.log("Available rfids:", rfidFromSocket);

    // Process the received file names here
    // For example, you can display them in the console or update the UI
    // Replace this with your desired logic to handle the received file names
  }
});

socket.addEventListener("close", () => {
  console.log("Connection to the WebSocket server closed");
});

Promise.all([
  faceapi.nets.ssdMobilenetv1.loadFromUri("../server/models"),
  faceapi.nets.faceRecognitionNet.loadFromUri("../server/models"),
  faceapi.nets.faceLandmark68Net.loadFromUri("../server/models"),
]).then(startWebcam);

function startWebcam() {
  navigator.mediaDevices
    .getUserMedia({
      video: true,
      audio: false,
    })
    .then((stream) => {
      videoElement.srcObject = stream;
    })
    .catch((error) => {
      console.error(error);
    });
}

async function fetchImage() {
  const retrieveRfid = [...rfidFromSocket];
  return Promise.all(
    retrieveRfid.map(async (rfid) => {
      const descriptions = [];
      for (let i = 1; i <= 2; i++) {
        const img = await faceapi.fetchImage(
          `../server/images/${rfid}/${i}.png`
        );

        const detections = await faceapi
          .detectSingleFace(img)
          .withFaceLandmarks()
          .withFaceDescriptor();

        // Check if a face is detected before accessing the descriptor
        if (detections) {
          descriptions.push(detections.descriptor);
        } else {
          console.log(`No face detected for ${rfid}/${i}.png`);
          // Handle the case where no face is detected, e.g., skip or log it
        }
      }
      return new faceapi.LabeledFaceDescriptors(rfid, descriptions);
    })
  );
}

videoElement.addEventListener("play", async () => {
  const labeledFaceDescriptors = await fetchImage();
  const faceMatcher = new faceapi.FaceMatcher(labeledFaceDescriptors);

  const canvas = faceapi.createCanvasFromMedia(videoElement);
  document.getElementById("videoContainer").append(canvas);

  const displaySize = {
    width: videoElement.width,
    height: videoElement.height,
  };

  faceapi.matchDimensions(canvas, displaySize);

  setInterval(async () => {
    const detections = await faceapi
      .detectAllFaces(videoElement)
      .withFaceLandmarks()
      .withFaceDescriptors();

    const resizedDetections = faceapi.resizeResults(detections, displaySize);

    canvas.getContext("2d").clearRect(0, 0, canvas.width, canvas.height);

    const results = resizedDetections.map((d) => {
      return faceMatcher.findBestMatch(d.descriptor);
    });

    results.forEach((result, i) => {
      const box = resizedDetections[i].detection.box;
      const drawBox = new faceapi.draw.DrawBox(box, {
        label: result.toString(),
      });

      drawBox.draw(canvas);

      // Check if the result is not unknown
      if (result.label !== "unknown") {
        // Extract the RFID from the label
        const rfid = result.label.split(" ")[0];
        // Store the matched RFID in the variable
        matchfaceRfid = rfid;
        // Check for attendance match inside the loop
        if (!matchRfid) {
          displayStatus.innerText = "Please punch your RFID!";
        } else if (matchRfid !== null && matchRfid === matchfaceRfid) {
          displayStatus.innerText = "You are now Present!";
        } else if (matchRfid !== null && matchRfid !== matchfaceRfid) {
          displayStatus.innerText = "RFID and face do not match!";
        }

        // Add console logs to debug and check the values
        console.log("matchRfid:", matchRfid);
        console.log("matchfaceRfid:", matchfaceRfid);
      }
    });
  }, 100);
});
