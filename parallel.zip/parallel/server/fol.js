const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();

app.get("/api/files", (req, res) => {
  const directoryPath = path.join(__dirname, "images");

  fs.readdir(directoryPath, (err, files) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      // Extracting only the file names without extensions
      const fileNames = files.map((file) => path.parse(file).name);
      res.json(fileNames);
    }
  });
});

const port = 3000;
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
