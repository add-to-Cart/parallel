<?php
include 'connection.php';

// Retrieve values from login form
$username = $_POST['floatingUsername'];
$password = $_POST['floatingPassword'];

// Perform SQL query to check user credentials
$stmt = $conn->prepare("SELECT * FROM tblusers WHERE username=?");
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    // Compare plaintext password (not recommended for security)
    if ($password === $row['password']) {
        // Password is correct (plaintext comparison - not recommended)
        session_start();
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $username;
        $_SESSION['role'] = $row['role'];
        header("Location: ../index.php");
        exit();
    } else {
        // Password is incorrect
        echo "Invalid password";
    }
} else {
    // Username not found
    echo "User not found";
}

$conn->close();
