<?php


// Destroy the session
session_destroy();

// Redirect to the login page or any other desired page after logout
header("Location: ../route/login.php"); // Replace login.php with your desired page
exit();
