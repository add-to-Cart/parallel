<?php
// Check if POST data is received
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $folderName = $_POST['folderName'];
    $imageData = $_POST['imageData'];

    // Create directory if it doesn't exist
    $directory = '../server/images/' . $folderName;
    if (!file_exists($directory)) {
        mkdir($directory, 0777, true);
    }

    // Generate a unique file name or incrementing index for the image
    $files = glob($directory . '/*');
    $fileIndex = count($files) + 1;
    $imageName = $directory . '/' . $fileIndex . '.png';

    // Save the image
    $file = fopen($imageName, 'wb');
    $data = explode(',', $imageData);
    fwrite($file, base64_decode($data[1]));
    fclose($file);

    echo 'Image saved successfully.';
} else {
    echo 'Invalid request.';
}
