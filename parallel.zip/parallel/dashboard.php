<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Parallel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>


</head>

<body>
    <nav class="navbar navbar-expand-lg border-bottom border-dark">
        <div class="container-fluid">
            <a class="navbar-brand fs-5 fw-bold" href="login.php">Parallel</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a id="navHome" class="nav-link active" aria-current="page" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a id="navBiometrics" class="nav-link" href="#">Capture</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Attendance</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">My Record</a>
                    </li>


                </ul>
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Christian Consulta
                        </a>
                        <ul class="dropdown-menu">

                            <li><a class="dropdown-item" href="#">Settings</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item text-danger" href="#">Logout</a></li>
                        </ul>
                    </li>
                </ul>

            </div>
        </div>
    </nav>
    <div id="dashboardContent">

    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    <script>
        $(document).ready(function() {
            const socket = new WebSocket('ws://localhost:5000'); // Connect to your Node.js server

            socket.onopen = function() {
                console.log('WebSocket connection established');
            };

            socket.onmessage = function(event) {
                // Handle messages received from Node.js in PHP
                console.log('Received rfid from server:', event.data);
                // Update your PHP application based on the received data

                // For example, updating an HTML element with received data
                document.getElementById("receivedData").innerText = event.data;
            };
            // Function to load attendance.php into dashboardContent
            function loadBiometrics() {
                $('#dashboardContent').load('biometricsregistration.php');
            }

            // Event handler for clicking on "Attendance" nav item
            $('#navBiometrics').on('click', function(e) {
                e.preventDefault(); // Prevent the default action (page reload)

                // Call the function to load attendance.php content
                loadBiometrics();
            });

            function loadHome() {
                $('#dashboardContent').load('home.php');
            }

            // Event handler for clicking on "Attendance" nav item
            $('#navHome').on('click', function(e) {
                e.preventDefault(); // Prevent the default action (page reload)

                // Call the function to load attendance.php content
                loadHome();
            });
        });
    </script>

</body>

</html>