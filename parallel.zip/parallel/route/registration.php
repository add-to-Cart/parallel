<?php session_start() ?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>

<body>
    <nav class="navbar navbar-expand-lg border-bottom border-dark">
        <div class="container-fluid">
            <a class="navbar-brand fs-5 fw-bold" href="login.php">Parallel</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a id="navHome" class="nav-link" aria-current="page" href="../index.php">Home</a>
                    </li>

                </ul>
                <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a id="navSignin" class="nav-link" aria-current="page" href="#">Sign in</a>
                    </li>

                </ul>

            </div>
        </div>
    </nav>

    <div class="container border rounded-3 mt-5">
        <div class="row py-3 text-center border-bottom">
            <h5>Registration for RFID: <span id="receivedData" class="text-success"></span></h5>
        </div>


        <div class="row py-4">
            <div class="col d-flex flex-column justify-content-center align-items-center px-5 pt-5">
                <video id="videoElement" width="300" autoplay muted></video>
                <div class="row mt-5">
                    <button id="captureBiometrics" class=" btn btn-outline-danger fw-medium">Capture Biometrics</button>
                </div>
            </div>
            <div class="col p-5">
                <form>
                    <div id="emptyFieldsAlert" class="alert alert-danger d-none" role="alert"></div>
                    <div class="mb-3">
                        <label for="fname" class="form-label">Firstname</label>
                        <input type="text" class="form-control" id="fname">
                    </div>
                    <div class="mb-3">
                        <label for="mname" class="form-label">Middlename</label>
                        <input type="text" class="form-control" id="mname">
                    </div>
                    <div class="mb-3">
                        <label for="lname" class="form-label">Lastname</label>
                        <input type="text" class="form-control" id="lname">
                    </div>
                    <div class="mb-3">
                        <label for="role" class="form-label">Role</label>
                        <select id="role" class="form-select" aria-label="Default select example" required>
                            <option selected>Please select role</option>
                            <option value="student">Student</option>
                            <option value="instructor">Instructor</option>
                            <option value="faculty">Faculty</option>
                        </select>
                    </div>

                    <div class="d-grid grid-gap-2 mt-5">
                        <button id="btnSubmitDetails" class="btn btn-dark">Submit</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
    <footer class="footer mt-auto py-3 bg-light">
        <div class="container text-center">
            <span class="text-muted">Parallel &copy; 2024. All rights reserved.</span>
        </div>
    </footer>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script>
        $(document).ready(function() {
            const socket = new WebSocket('ws://localhost:5000'); // Connect to your Node.js server

            socket.onopen = function() {
                console.log('WebSocket connection established');
            };

            socket.onmessage = function(event) {
                // Handle messages received from Node.js in PHP
                console.log('Received rfid from server:', event.data);
                // Update your PHP application based on the received data

                // For example, updating an HTML element with received data
                document.getElementById("receivedData").innerText = event.data;

            };

            function captureAndSaveImage() {
                const receivedData = $('#receivedData').text().trim();

                if (receivedData !== '') {
                    const video = $('#videoElement')[0];
                    const canvas = document.createElement('canvas');
                    const context = canvas.getContext('2d');

                    canvas.width = video.videoWidth;
                    canvas.height = video.videoHeight;

                    context.drawImage(video, 0, 0, canvas.width, canvas.height);

                    const imageDataURL = canvas.toDataURL('image/png');

                    // Sending the image data to the server using AJAX
                    $.ajax({
                        url: '../php/save_image.php',
                        type: 'POST',
                        data: {
                            folderName: receivedData,
                            imageData: imageDataURL
                        },
                        success: function(response) {
                            console.log(response);
                        },
                        error: function(error) {
                            console.error('Error saving image:', error);
                        }
                    });
                } else {
                    console.error('No received rfid to create a folder.');
                }
            }

            $('#captureBiometrics').on('click', captureAndSaveImage);
            if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
                navigator.mediaDevices.getUserMedia({
                        video: true
                    })
                    .then(function(stream) {
                        var video = $('#videoElement')[0];
                        if ('srcObject' in video) {
                            video.srcObject = stream;
                        } else {
                            video.src = window.URL.createObjectURL(stream);
                        }
                        video.onloadedmetadata = function(e) {
                            video.play();
                        };
                    })
                    .catch(function(err) {
                        console.error("Error accessing the camera: " + err);
                    });
            } else {
                console.error("getUserMedia is not supported");
            }

            function submitFormToDatabase(event) {
                event.preventDefault(); // Prevent form submission

                const fname = $('#fname').val().trim();
                const mname = $('#mname').val().trim();
                const lname = $('#lname').val().trim();
                const role = $('#role').val().trim();
                // const username = $('#username').val().trim();
                // const password = $('#password').val().trim();
                // const confirmPassword = $('#cpassword').val().trim();
                const receivedData = $('#receivedData').text().trim();

                if (receivedData === '') {

                    $('#emptyFieldsAlert').text('Invalid RFID');
                    $('#emptyFieldsAlert').removeClass('d-none');
                    return; // Stop form submission
                } else if (fname == '' || lname == '') {
                    // Check if passwords match

                    $('#emptyFieldsAlert').removeClass('d-none').text('Please fill in both first name and last name.'); // Show the alert
                    return; // Stop form submission
                } else if (role === 'Please select role') {
                    $('#emptyFieldsAlert').removeClass('d-none').text('Please select a valid role.');
                    return; // Stop form submission
                }
                /*else if (password == '' || confirmPassword == '') {
                                   // Check if passwords match
                                   $('#emptyFieldsAlert').removeClass('d-none').text('Passwords cannot be empty.'); // Show the alert
                                   return; // Stop form submission
                               } else if (password !== confirmPassword) {
                                   // Check if passwords match
                                   $('#emptyFieldsAlert').removeClass('d-none').text('Passwords do not match'); // Show the alert
                                   return; // Stop form submission
                               } */
                else {
                    $('#emptyFieldsAlert').addClass('d-none'); // Hide the alert if previously shown
                    // Continue with form submission or data processing here

                    $.ajax({
                        url: '../php/save_registration.php', // Replace with your PHP file handling MySQL insertion
                        type: 'POST',
                        data: {
                            fname: fname,
                            mname: mname,
                            lname: lname,
                            role: role,
                            rfid: receivedData
                        },
                        success: function(response) {
                            console.log(response);
                            // Optionally, do something after successful insertion
                        },
                        error: function(error) {
                            console.error('Error inserting data:', error);
                        }
                    });
                }
            }

            $('#btnSubmitDetails').on('click', submitFormToDatabase);

        });
    </script>
</body>

</html>