<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sessions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>

<body>
    <div class="container mt-4">
        <div class="row">
            <div class="col fw-medium fs-5">Attendance Records</div>
            <div class="col">
                <input id="selectInstructor" name="selectInstructor" class="form-control" type="text" placeholder="Enter Instructor Name">
            </div>
        </div>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>RFID</th>
                    <th>First Name</th>
                    <th>Middle Name</th>
                    <th>Last Name</th>
                    <th>Instructor</th>

                    <th>Time In</th>
                    <th>Date Attended</th>
                </tr>
            </thead>
            <tbody id="attendanceTable">
                <!-- Attendance data will be displayed here -->
                <!-- You can use JavaScript to dynamically populate this section -->
                <!-- For this example, let's assume the data is fetched from a server -->
            </tbody>
        </table>
    </div>

    <footer class="footer mt-auto py-3 bg-light">
        <div class="container text-center">
            <span class="text-muted">Parallel &copy; 2024. All rights reserved.</span>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script>
        function fetchData() {
            fetch('../php/fetch_classes.php') // Create a PHP file 'fetch_data.php' to handle data retrieval
                .then(response => response.text())
                .then(data => {
                    document.getElementById('attendanceTable').innerHTML = data;
                })
                .catch(error => {
                    console.error('Error fetching data:', error);
                });
        }

        // Call the function to initially populate the table
        fetchData();

        // Polling - Fetch data every 5 seconds
        setInterval(fetchData, 5000);


        function updateTableData() {
            const selectedInstructor = document.getElementById('selectInstructor').value;
            fetch(`../php/search_instructor.php?instructor=${selectedInstructor}`)
                .then(response => response.text())
                .then(data => {
                    document.getElementById('attendanceTable').innerHTML = data;
                })
                .catch(error => {
                    console.error('Error fetching data:', error);
                });
        }

        document.getElementById('selectInstructor').addEventListener('input', updateTableData);
    </script>
</body>

</html>