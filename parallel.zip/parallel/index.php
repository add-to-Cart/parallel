<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Parallel</title>
</head>

<body>
    <nav class="navbar navbar-expand-lg border-bottom">
        <div class="container-fluid">
            <a class="navbar-brand fs-5 fw-bold" href="login.php">Parallel</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a id="navHome" class="nav-link active" aria-current="page" href="index.php">Home</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="route/registration.php">Registration</a>
                    </li>

                    <li class="nav-item">
                        <a id="navAttendance" class="nav-link" href="route/attendance.php">Attendance</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="route/sessions.php">Sessions</a>
                    </li>

                </ul>

            </div>
        </div>
    </nav>

    <div class="container-fluid mt-5">
        <div class="row p-3">
            <h1>Welcome to Parallel</h1>
            <p>
                Parallel is an attendance system designed to integrate RFID and facial recognition as two-factor authentication methods, significantly reducing manual attendance recording and enhancing security.
            </p>
        </div>


        <div class="row mt-3">
            <div class="col-lg-12">
                <div class="card mb-4">
                    <div class="card-body">
                        <h3 class="card-title">Registration</h3>
                        <p class="card-text">
                            The Registration section allows users to input and register essential personal data, with a focus on RFID technology. The registered RFID serves as a unique identifier linked to the user's data, facilitating actions such as image capturing. <a class="text-decoration-none" href="route/registration.php">Register here.</a>
                        </p>

                    </div>
                </div>
            </div>

            <div class="col-lg-12">
                <div class="card mb-4">
                    <div class="card-body">
                        <h3 class="card-title">Attendance Recording</h3>
                        <p class="card-text">
                            The Attendance section enables users to conveniently record attendance by using RFID and facial recognition technology. This dual verification method ensures accurate attendance tracking. <a class="text-decoration-none" href="route/attendance.php">Capture attendance.</a>
                        </p>
                    </div>
                </div>
            </div>

            <div class="col-lg-12">
                <div class="card mb-4">
                    <div class="card-body">
                        <h3 class="card-title">Session Management</h3>
                        <p class="card-text">
                            The Sessions section provides an overview of recorded attendance across different sessions, aiding in tracking and monitoring attendance history over various events. <a class="text-decoration-none" href="route/sessions.php">View sessions.</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>


    </div>

    <footer class="footer mt-auto py-3 bg-light">
        <div class="container text-center">
            <span class="text-muted">Parallel &copy; 2024. All rights reserved.</span>
        </div>
    </footer>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const socket = new WebSocket('ws://localhost:5001'); // Connect to your Node.js server

        socket.onopen = function() {
            console.log('WebSocket connection established');
        };

        socket.onmessage = function(event) {
            // Handle messages received from Node.js in PHP
            console.log('Received rfid from server:', event.data);
            // Update your PHP application based on the received data

            // For example, updating an HTML element with received data
            document.getElementById("rfid").value = event.data;

        };
    </script>
</body>

</html>