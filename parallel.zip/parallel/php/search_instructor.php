<?php
include 'connection.php';

if (isset($_GET['instructor'])) {
    $selectedInstructor = $_GET['instructor'];

    $sql = "SELECT * FROM tblattendance_s WHERE instructor LIKE '%$selectedInstructor%'";
    $result = $conn->query($sql);

    // Generate HTML table rows with updated data
    $tableRows = '';
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $tableRows .= "<tr>";
            $tableRows .= "<td>{$row['rfid']}</td>";
            $tableRows .= "<td>{$row['firstname']}</td>";
            $tableRows .= "<td>{$row['middlename']}</td>";
            $tableRows .= "<td>{$row['lastname']}</td>";
            $tableRows .= "<td>{$row['instructor']}</td>";
            $tableRows .= "<td>{$row['time_in']}</td>";
            $tableRows .= "<td>{$row['date_attended']}</td>";
            $tableRows .= "</tr>";
        }
    } else {
        $tableRows = "<tr><td colspan='8'>No records found</td></tr>";
    }

    $conn->close();

    // Output HTML table rows
    echo $tableRows;
}
