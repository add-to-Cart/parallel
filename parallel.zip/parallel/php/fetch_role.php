<?php
// Include the database connection details from a separate file
include 'connection.php';

// Handle POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);

    // Validate received data
    if (isset($data['rfid'])) {
        try {
            // Check if the ID exists in the students table
            $stmt = $conn->prepare("SELECT * FROM tbluserinfo WHERE rfid = ?");
            $stmt->bind_param('s', $data['rfid']);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $student = $result->fetch_assoc();
                $roleInfo = [
                    'rfid' => $student['rfid'],
                    'firstname' => $student['firstname'],
                    'lastname' => $student['lastname'],
                    'middlename' => $student['middlename'],
                    'role' => $student['role']
                ];
                echo json_encode(['success' => true, 'roleInfo' => $roleInfo]);
                exit; // Ensure nothing else is output after JSON data
            } else {
                echo json_encode(['success' => false, 'message' => 'Student not found.']);
                exit; // Ensure nothing else is output after JSON data
            }
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Database query failed: ' . $e->getMessage()]);
            exit; // Ensure nothing else is output after JSON data
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid data received.']);
        exit; // Ensure nothing else is output after JSON data
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
    exit; // Ensure nothing else is output after JSON data
}
