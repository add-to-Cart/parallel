<?php
include 'connection.php';

function insertAttendance($conn, $instructorRfid, $instructorFirstname, $instructorMiddlename, $instructorLastname)
{
    $stmtInstructor = $conn->prepare("INSERT INTO tblattendance_i (rfid, firstname, middlename, lastname) VALUES (?, ?, ?, ?)");
    $stmtInstructor->bind_param('ssss', $instructorRfid, $instructorFirstname, $instructorMiddlename, $instructorLastname);
    $stmtInstructor->execute();
    return $stmtInstructor;
}

$inputJSON = file_get_contents('php://input');
$data = json_decode($inputJSON, true);

if (!isset($data['instructorInfo'])) {
    echo json_encode(array("success" => false, "message" => "Instructor information missing"));
    exit();
}

try {
    $conn = $GLOBALS['conn'];

    $conn->begin_transaction();

    $instructorInfo = $data['instructorInfo'];

    $stmt = insertAttendance(
        $conn,
        $instructorInfo['rfid'] ?? null,
        $instructorInfo['firstname'] ?? '',
        $instructorInfo['middlename'] ?? '',
        $instructorInfo['lastname'] ?? ''
    );

    $conn->commit();
    $conn->close();

    echo json_encode(array("success" => true, "message" => "Attendance inserted successfully"));
} catch (Exception $e) {
    if (isset($conn)) {
        $conn->rollback();
        $conn->close();
    }

    $error_message = "Error: " . $e->getMessage();
    error_log($error_message, 0);
    echo json_encode(array("success" => false, "message" => $error_message));
}
