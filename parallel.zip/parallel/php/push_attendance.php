<?php
include 'connection.php';

function insertAttendance($conn, $rfid, $firstname, $middlename, $lastname)
{
    $stmt = $conn->prepare("INSERT INTO tblattendance_i (rfid, firstname, middlename, lastname) VALUES (?, ?, ?, ?)");
    $stmt->bind_param('ssss', $rfid, $firstname, $middlename, $lastname);
    $stmt->execute();
    return $stmt;
}

$inputJSON = file_get_contents('php://input');
$data = json_decode($inputJSON, true);

if (!isset($data['instructorInfo'])) {
    echo json_encode(array("success" => false, "message" => "Instructor information missing"));
    exit();
}

try {
    $conn = $GLOBALS['conn'];
    $conn->autocommit(false);

    $instructorInfo = $data['instructorInfo'];

    $instructorRfid = $instructorInfo['rfid'] ?? null;
    $instructorFirstname = $instructorInfo['firstname'] ?? '';
    $instructorMiddlename = $instructorInfo['middlename'] ?? '';
    $instructorLastname = $instructorInfo['lastname'] ?? '';

    $stmtInstructor = insertAttendance($conn, $instructorRfid, $instructorFirstname, $instructorMiddlename, $instructorLastname);

    if (isset($data['studentsArray'])) {
        $studentsArray = $data['studentsArray'];

        $stmtStudent = $conn->prepare("INSERT INTO tblattendance_s (rfid, firstname, middlename, lastname, instructor) VALUES (?, ?, ?, ?, ?)");

        foreach ($studentsArray as $student) {
            $studentRfid = $student['rfid'] ?? null;
            $studentFirstname = $student['firstname'] ?? '';
            $studentMiddlename = $student['middlename'] ?? '';
            $studentLastname = $student['lastname'] ?? '';

            if ($studentRfid !== null) {
                $stmtStudent->bind_param('sssssss', $studentRfid, $studentFirstname, $studentMiddlename, $studentLastname, "$instructorLastname, $instructorFirstname $instructorMiddlename");
                $stmtStudent->execute();
            }
        }
    }

    $conn->commit();
    $conn->close();

    echo json_encode(array("success" => true, "message" => "Attendance inserted successfully"));
} catch (Exception $e) {
    if (isset($conn)) {
        $conn->rollback();
        $conn->close();
    }

    $error_message = "Error: " . $e->getMessage();
    error_log($error_message, 0);
    echo json_encode(array("success" => false, "message" => $error_message));
}
