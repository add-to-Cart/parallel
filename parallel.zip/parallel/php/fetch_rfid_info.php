<?php
include 'connection.php';

function fetchRfidInfo($conn, $rfid)
{
    // Prevent SQL injection by using prepared statements
    $sql = "SELECT * FROM tbluserinfo WHERE rfid = ?";

    // Prepare and bind the statement
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $rfid);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $data = array();
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        return $data; // Return the fetched data
    } else {
        return array("error" => "No records found");
    }
}

// Check if the 'rfid' parameter is passed in the URL
if (isset($_GET['rfid'])) {
    $rfid = $_GET['rfid'];
    echo json_encode(fetchRfidInfo($conn, $rfid)); // Output JSON-encoded data based on the provided RFID
} else {
    echo json_encode(array("error" => "RFID not provided"));
}

$conn->close();
