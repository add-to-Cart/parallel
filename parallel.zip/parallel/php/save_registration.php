<?php
// mga naka comment yung dinebug
include 'connection.php';

// Get form data sent via POST request
$firstname = $_POST['fname'];
$middlename = $_POST['mname'];
$lastname = $_POST['lname'];
$role = $_POST['role'];
$rfid = $_POST['rfid'];

// Check for duplication in tbluserinfo based on rfid
$duplicateCheckUserinfo = $conn->prepare("SELECT rfid FROM tbluserinfo WHERE rfid = ?");
$duplicateCheckUserinfo->bind_param("s", $rfid);
$duplicateCheckUserinfo->execute();
$duplicateUserinfoResult = $duplicateCheckUserinfo->get_result();
if ($duplicateUserinfoResult->num_rows > 0) {
    echo "Error: RFID already exists in tbluserinfo";
    exit(); // Stop further execution if duplication found
}

// // Check for duplication in tblusers based on username
// $duplicateCheckUsers = $conn->prepare("SELECT username FROM tblusers WHERE username = ?");
// $duplicateCheckUsers->bind_param("s", $username);
// $duplicateCheckUsers->execute();
// $duplicateUsersResult = $duplicateCheckUsers->get_result();
// if ($duplicateUsersResult->num_rows > 0) {
//     echo "Error: Username already exists in tblusers";
//     exit(); // Stop further execution if duplication found
// }

// SQL statements to insert data into tbluserinfo and tblusers tables
$sqlUserinfo = "INSERT INTO tbluserinfo (rfid, firstname, middlename, lastname, role) VALUES (?, ?, ?, ?, ?)";
//$sqlUsers = "INSERT INTO tblusers (username, password, role) VALUES (?, ?, ?)";

// Prepare and bind the statements to prevent SQL injection
$stmtUserinfo = $conn->prepare($sqlUserinfo);
$stmtUserinfo->bind_param("sssss", $rfid, $firstname, $middlename, $lastname, $role);

//$stmtUsers = $conn->prepare($sqlUsers);
//$stmtUsers->bind_param("sss", $username, $password, $role);

// Execute the prepared statements
$userinfoInserted = $stmtUserinfo->execute();
//$usersInserted = $stmtUsers->execute();

if ($userinfoInserted /*&& $usersInserted*/) {
    echo "Data inserted successfully into both tables";
} else {
    echo "Error inserting data: " . $conn->error;
}

// Close statements and connection
$stmtUserinfo->close();
//$stmtUsers->close();
$conn->close();
