<?php
include 'connection.php';

function insertAttendance($conn, $data, $instructorName)
{
    $stmtStudent = $conn->prepare("INSERT INTO tblattendance_s (rfid, firstname, middlename, lastname, instructor) VALUES (?, ?, ?, ?, ?)");
    $stmtStudent->bind_param('sssss', $data['student']['rfid'], $data['student']['firstname'], $data['student']['middlename'], $data['student']['lastname'], $instructorName);
    $stmtStudent->execute();

    return $stmtStudent;
}

$inputJSON = file_get_contents('php://input');
$data = json_decode($inputJSON, true);

if (!isset($data['instructorInfo'], $data['student'])) {
    echo json_encode(array("success" => false, "message" => "Instructor or student information missing"));
    exit();
}

try {
    $conn = $GLOBALS['conn'];

    $conn->begin_transaction();

    $instructorInfo = $data['instructorInfo'];
    $student = $data['student'];

    $instructorName = "{$instructorInfo['firstname']} {$instructorInfo['middlename']} {$instructorInfo['lastname']}";

    $stmt = insertAttendance($conn, $data, $instructorName);

    $conn->commit();
    $conn->close();

    echo json_encode(array("success" => true, "message" => "Attendance inserted successfully"));
} catch (Exception $e) {
    if (isset($conn)) {
        $conn->rollback();
        $conn->close();
    }

    $error_message = "Error: Something went wrong while inserting attendance";
    error_log($error_message . " - " . $e->getMessage(), 0);
    echo json_encode(array("success" => false, "message" => $error_message));
}
