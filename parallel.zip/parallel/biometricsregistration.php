<div class="container d-flex flex-column justify-content-center align-items-center vh-100">

    <div class="row text-center">

        <p class="text-success">Register face with RFID: <span id="receivedData"></span></p>
    </div>

    <div class="row justify-content-center mb-3">
        <video id="videoElement" width="200" autoplay muted></video>
    </div>

    <div class="row">
        <button id="captureBiometrics" class=" btn btn-outline-danger btn-lg fw-medium">Capture Biometrics</button>
    </div>



</div>

<script>
    $(document).ready(function() {
        function captureAndSaveImage() {
            const receivedData = $('#receivedData').text().trim();

            if (receivedData !== '') {
                const video = $('#videoElement')[0];
                const canvas = document.createElement('canvas');
                const context = canvas.getContext('2d');

                canvas.width = video.videoWidth;
                canvas.height = video.videoHeight;

                context.drawImage(video, 0, 0, canvas.width, canvas.height);

                const imageDataURL = canvas.toDataURL('image/jpeg');

                // Sending the image data to the server using AJAX
                $.ajax({
                    url: 'saveimage.php',
                    type: 'POST',
                    data: {
                        folderName: receivedData,
                        imageData: imageDataURL
                    },
                    success: function(response) {
                        console.log(response);
                    },
                    error: function(error) {
                        console.error('Error saving image:', error);
                    }
                });
            } else {
                console.error('No received data to create a folder.');
            }
        }

        $('#captureBiometrics').on('click', captureAndSaveImage);
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            navigator.mediaDevices.getUserMedia({
                    video: true
                })
                .then(function(stream) {
                    var video = $('#videoElement')[0];
                    if ('srcObject' in video) {
                        video.srcObject = stream;
                    } else {
                        video.src = window.URL.createObjectURL(stream);
                    }
                    video.onloadedmetadata = function(e) {
                        video.play();
                    };
                })
                .catch(function(err) {
                    console.error("Error accessing the camera: " + err);
                });
        } else {
            console.error("getUserMedia is not supported");
        }
    });
</script>