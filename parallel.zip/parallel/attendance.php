<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script defer src="/parallel/server/face-api.min.js"></script>
    <script defer src="/parallel/server/script.js"></script>
    <style>
        canvas {
            position: absolute;
        }
    </style>
</head>

<body>
    <div id="videoContainer" class="container d-flex justify-content-center align-items-center vh-100">
        <video id="faceVideo" width="600" height="450" autoplay>
    </div>


</body>

</html>